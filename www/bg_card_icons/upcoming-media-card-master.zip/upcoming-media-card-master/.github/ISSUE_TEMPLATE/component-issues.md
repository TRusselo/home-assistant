---
name: Issues for Components (Radarr, Sonarr, Plex, etc.)
about: DO NOT POST HERE, POST ON THE COMPONENT'S PAGE.
title: ''
labels: invalid, wontfix
assignees: ''

---

Do not post issues for the components here (radarr, sonarr, etc).
Post those issues on the components github pages.

If you submit an issue with this template, it will be closed immediately.
